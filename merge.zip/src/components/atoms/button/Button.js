import React from "react";

function Button({
  children,
  className,
  onClick,
  leftIcon,
  rightIcon,
  outlined = false,
  filled = false,
}) {
  return (
    <button
      className={`flex flex-row gap-2 items-center heading3 py-2 px-4 rounded-full ${
        filled ? "bg-greyWhite" : "bg-transparent"
      } border-[1px] ${
        outlined
          ? " border-greyWhite hover:bg-greyWhite text-greyWhite hover:text-greyBlack"
          : "border-transparent"
      } ${className} `}
    >
      {leftIcon && leftIcon}
      {children}
      {rightIcon && rightIcon}
    </button>
  );
}

export default Button;
