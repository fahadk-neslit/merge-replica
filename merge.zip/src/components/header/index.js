"use client";
import React from "react";
import Button from "../atoms/button/Button";

function Header() {
  return (
    <div className="body-padding sticky top-0 left-0 flex flex-row justify-between items-center bg-primary text-greyWhite py-[28px]">
      <div>
        <h1 className="heading2">merge</h1>
      </div>
      <div className="hidden md:flex gap-5">
        <Button>Services</Button>
        <Button>Case Studies</Button>
        <Button>About</Button>
        <Button>Resources</Button>
      </div>
      <div>
        <Button outlined>Contact Us</Button>
      </div>
    </div>
  );
}

export default Header;
