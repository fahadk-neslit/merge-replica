import Button from "@/components/atoms/button/Button";
import React from "react";
import { AiOutlineRight } from "react-icons/ai";

function Home() {
  return (
    <div className="py-[70px] bg-primary w-full min-h-full flex flex-col items-center">
      <div>
        <h4 className="heading1 text-greyWhite text-center">
          UX first SaaS and fintech
        </h4>
        <p className="paragraph1 text-center mt-[24px]">
          We assist startups in building software, experimenting with new
          features,
          <br /> and bringing their product vision to life.
        </p>
      </div>
      <Button
        rightIcon={<AiOutlineRight />}
        filled
        className="bg-white mt-[52px]"
      >
        Let&apos;s talk
      </Button>
      <div className="mt-[136px] w-[1026px] h-[592px] rounded-3xl bg-greyWhite">
        {/* Video container */}
      </div>
      <h2 className="heading1 text-greyWhite text-center mt-[160px]">
        Our services
        <span className="text-foggyGrey opacity-50"> and capabilities</span>
      </h2>
    </div>
  );
}

export default Home;
